Automatic Name Generation
==========================

.. automodule:: pyro.contrib.autoname
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

Named Data Structures
---------------------

.. automodule:: pyro.contrib.autoname.named
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

Scoping
-------

.. automodule:: pyro.contrib.autoname.scoping
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
